// input: num_cores - the number of FSTP cores.;
// input: num_gps - the number of GTP GPs.;
// we default initialize the inputs so that generate_derived_ctr_plists.py does not deduce that they are counters
var num_cores = 4;
var num_gps = 4;
var _d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a = 768;
var _55d0c180ad87ec962138c5c289baadd6969fdd2cd21ef68ab1f91190b6c33812 = 32;

// name: GPU Time
// description: GPU Time in nSec
// type: Count
function GPUTime()
{
    return MTLStat_nSec;
}

// name: Vertex Pipeline %
// description: % of vertex processing
// type: Percentage
function VertexPipelinePercent()
{
    return (MTLStatTotalGPUCycles_vtx * 100) / (MTLStatTotalGPUCycles_frg + MTLStatTotalGPUCycles_vtx);    
}

// name: Fragment Pipeline %
// description: % of fragment processing
// type: Percentage
function FragmentPipelinePercent()
{
    return (MTLStatTotalGPUCycles_frg * 100) / (MTLStatTotalGPUCycles_frg + MTLStatTotalGPUCycles_vtx);
}

// name: Shader Core Vertex Utilization %
// description: % Shader Core Vertex Utilization
// type: Percentage
function ShaderCoreVertexUtilization()
{
    return _4bb4a72bfa974f38e0143eef87e93ae69847e8612684f014350fb4a8c0692050_norm_vtx / (_d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a * num_cores);
}

// name: Shader Core Fragment Utilization %
// description: % Shader Core Fragment Utilization
// type: Percentage
function ShaderCoreFragmentUtilization()
{
    return _367a60a3f4d39b45114c57a560ad1bad4f9f62798346ead3a98f790ad32537a6_norm_frg / (_d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a * num_cores);
}

// name: Shader Core Compute Utilization %
// description: % Shader Core Compute Utilization
// type: Percentage
function ShaderCoreComputeUtilization()
{
    return _6b3a9b25a65b692ad1039bcc4c052d5a85e40a9410946c0cdf5dc85d993e2131_norm / (_d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a * num_cores);
}

// name: VS ALU Instructions
// description: VS ALU Instructions
// type: Count
function VSALUInstructions()
{ 
    return (_55d0c180ad87ec962138c5c289baadd6969fdd2cd21ef68ab1f91190b6c33812 / 2) * _c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_vtx * 4;
}

// name: VS ALU FP32 Instructions %
// description: VS ALU FP32 Instructions
// type: Percentage
function VSALUF32Percent()
{
    return 100 * (_8e70441b8b0d9ded3ed900ec761f9f5960b106c5a304b44d62781621d5d1861a_vtx * 16) / VSALUInstructions();
}

// name: VS ALU FP16 Instructions %
// description: VS ALU FP16 Instructions
// type: Percentage
function VSALUF16Percent()
{
    return 100 * (_82b2f93079459b00fb869444cfcf44604cc1a91d28078cd6bfd7bb6ea6ba423d_vtx * 16) / VSALUInstructions();
}

// name: VS ALU 32-bit Integer and Conditional Instructions %
// description: VS ALU Select, Conditional, 32-bit Integer and Boolean Instructions
// type: Percentage
function VSALUInt32AndCondPercent()
{
    return 100 * (_23c51175314006fa4b6798dcb173a814349e2e5947244cfdba868be736d2bc03_vtx * 16) / VSALUInstructions();
}

// name: VS ALU Integer and Complex Instructions %
// description: VS ALU Integer and Complex Instructions
// type: Percentage
function VSALUIntAndComplexPercent()
{
    return 100 * (_827783963eafa9275a53fc2b3ef13214ab90939fcc81572c4260e2eac9bd2acb_vtx * 16) / VSALUInstructions();
}

// name: FS ALU Instructions
// description: FS ALU Instructions
// type: Count
function FSALUInstructions()
{
    return (_55d0c180ad87ec962138c5c289baadd6969fdd2cd21ef68ab1f91190b6c33812 / 2) * _c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_frg * 4;
}

// name: FS ALU FP32 Instructions %
// description: FS ALU FP32 Instructions
// type: Percentage
function FSALUF32Percent()
{
    return 100 * (_8e70441b8b0d9ded3ed900ec761f9f5960b106c5a304b44d62781621d5d1861a_frg * 16) / FSALUInstructions();
}

// name: FS ALU FP16 Instructions %
// description: FS ALU FP16 Instructions
// type: Percentage
function FSALUF16Percent()
{
    return 100 * (_82b2f93079459b00fb869444cfcf44604cc1a91d28078cd6bfd7bb6ea6ba423d_frg * 16) / FSALUInstructions();
}

// name: FS ALU 32-bit Integer and Conditional Instructions %
// description: FS ALU Select, Conditional, 32-bit Integer and Boolean Instructions
// type: Percentage
function FSALUInt32AndCondPercent()
{
    return 100 * (_23c51175314006fa4b6798dcb173a814349e2e5947244cfdba868be736d2bc03_frg * 16) / FSALUInstructions();
}

// name: FS ALU Integer and Complex Instructions %
// description: FS ALU Integer and Complex Instructions
// type: Percentage
function FSALUIntAndComplexPercent()
{
    return 100 * (_827783963eafa9275a53fc2b3ef13214ab90939fcc81572c4260e2eac9bd2acb_frg * 16) / FSALUInstructions();
}

// name: CS ALU Instructions
// description: CS ALU Instructions
// type: Count
function CSALUInstructions()
{
    return (_55d0c180ad87ec962138c5c289baadd6969fdd2cd21ef68ab1f91190b6c33812 / 2) * _c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_cmp * 4;
}

// name: CS ALU FP32 Instructions %
// description: CS ALU FP32 Instructions
// type: Percentage
function CSALUF32Percent()
{
    return 100 * (_8e70441b8b0d9ded3ed900ec761f9f5960b106c5a304b44d62781621d5d1861a_cmp * 16) / CSALUInstructions();
}

// name: CS ALU FP16 Instructions %
// description: CS ALU FP16 Instructions
// type: Percentage
function CSALUF16Percent()
{
    return 100 * (_82b2f93079459b00fb869444cfcf44604cc1a91d28078cd6bfd7bb6ea6ba423d_cmp * 16) / CSALUInstructions();
}

// name: CS ALU 32-bit Integer and Conditional Instructions %
// description: CS ALU Select, Conditional, 32-bit Integer and Boolean Instructions
// type: Percentage
function CSALUInt32AndCondPercent()
{
    return 100 * (_23c51175314006fa4b6798dcb173a814349e2e5947244cfdba868be736d2bc03_cmp * 16) / CSALUInstructions();
}

// name: CS ALU Integer and Complex Instructions %
// description: CS ALU Integer and Complex Instructions
// type: Percentage
function CSALUIntAndComplexPercent()
{
    return 100 * (_827783963eafa9275a53fc2b3ef13214ab90939fcc81572c4260e2eac9bd2acb_cmp * 16) / CSALUInstructions();
}

// name: VS Invocations
// description: Number of times vertex shader is invoked
// type: Count
function VSInvocation()
{
    return _da2d5f5fd43e7edda6d5635752a29f09d285cf47c2ecd0a1b83b1ba3eddcef55_vtx;
}

// name: FS Invocations
// description: Number of times fragment shader is invoked
// type: Count
function PSInvocation()
{
    return _448897b2730c90c177c3e468d3780d048b4ef0c6feb09887550eb9e5e71373c0 * 32;
}

// name: CS Invocations
// description: Number of times compute shader is invoked
// type: Count
function CSInvocation()
{
    return _81ab3a8ce1b2bbc0614d42ac61ffdb4776f32f25876ceb5a6f8a7ab6052d7e78 + _701a5b3c3d51585a0ef9b9f6028c1e74885478f7c92816641ea12d44d9f0ab82 + _afdb4a37e17d46ff6d66c1c4f9582f7d91ae0fcb6ae5ea3d07c965f0467ef73a + _5b17fade7d6bf4ac17237a2805f1975b03b5924f7f39d31777d6c16dfb9c4489;
}

// name: Vertex Rate
// description: Number of vertices processed per nanosecond
// type: Rate
function VerticesPerNSec()
{
    return VSInvocation() / MTLStat_nSec_vtx;
}

// name: Primitive Rate
// description: Number of primitives processed per nanosecond
// type: Rate
function PrimitivesPerNSec()
{
    return PrimitivesSubmitted() / MTLStat_nSec_vtx;
}

// name: Pixel Rate
// description: Number of fragments processed per nanosecond
// type: Rate
function PixelsPerNSec()
{
    return PSInvocation() / MTLStat_nSec_frg;
}

// name: Pixel To Vertex Ratio
// description: Number of pixels per vertex
// type: Rate
function PixelToVertexRatio()
{
    return PSInvocation() / VSInvocation();
}

// name: Pixel Per Triangle
// description: Number of pixels per triangle
// type: Rate
function PixelPerTriangle()
{
    return PSInvocation() / PrimitivesSubmitted();
}

// name: Draw Calls
// description: Number of draw calls
// type: Count
function DrawCalls()
{
    return _f6c3f9b835930ff834f081ab2dfaacbdfbe451f6f2100abcdecec1c3c7999e0b_vtx / num_gps;
}

// name: Vertex Count
// description: Number of vertices being submitted to input assembly
// type: Count
function VerticesSubmitted()
{
    return _427543bc9ae51e5f3520629f8bbe54e3a18d14de616f0c418cf7190a55cd7d9c_vtx;
}

// name: Vertices Reused
// description: Number of vertices being reused
// type: Count
function VerticesReused()
{
    return VerticesSubmitted() - VSInvocation();
}

// name: Vertices Reused %
// description: % of vertices being reused
// type: Percentage
function VerticesReusedPercent()
{
    return (VerticesSubmitted() - VSInvocation()) * 100 / VerticesSubmitted();
}

// name: Primitives Submitted
// description: Number of primitives gathered by input assembly
// type: Count
function PrimitivesSubmitted()
{
    return _0c33d520d54b5d5f84a71398d6ae71152426874088128bd3c18ad78df5f6d8b7_vtx;
}

// name: Primitives Rasterized
// description: Number of primitives rasterized
// type: Count
function PrimitivesRasterized()
{
    return _2d3c257f33af88b8488658fb5b6a86f64cb02169b680e1250d3f37d373a4197f_vtx;
}

// name: Primitives Rendered %
// description: % of primitives rasterized
// type: Percentage
function PrimitivesRasterizedPercent()
{
    return PrimitivesRasterized() * 100 / PrimitivesSubmitted();
}

// name: Primitives Culled
// description: Number of primitives being culled
// type: Count
function CulledPrimitives()
{
    return BackFaceZeroAreaCullPrims() + GuardBandCullPrims() + OffscreenCullPrims();
}

// name: Primitives Culled %
// description: % of primitives being culled
// type: Percentage
function CulledPrimitivesPercent()
{
    return CulledPrimitives() * 100 / PrimitivesSubmitted();
}

// name: Primitives Clipped
// description: Number of primitives being clipped
// type: Count
function ClippedPrimitives()
{
    return _29091329a1ff8f86d51ab9b84da709de18ba8aa1d94003a519a0663db7add4a1_vtx + _6169af48fcc4f2c5d036243de6acd153bd0308c644bd7e4afc67499ad1aef2c7_vtx;
}

// name: Primitives Clipped %
// description: % of primitives clipped
// type: Percentage
function ClippedPrimitivesPercent()
{
    return ClippedPrimitives() * 100 / PrimitivesSubmitted();
}

// name: Back-Facing/Zero Area Cull Primitives
// description: Number of primitives being culled due to being back-facing or having zero area coverage
// type: Count
function BackFaceZeroAreaCullPrims()
{
    return _b466c606c4b7e98fcde3adad24a292c946f1f1130670918262ebf9f660e0173c_vtx + _01038280d9d6c505432733b12946359b7c301c69b32369f4b921b6fa206c2211_vtx;
}

// name: Back-Facing/Zero Area Cull Primitives %
// description: % of primitives being culled due to being back-facing or having zero area coverage
// type: Percentage
function BackFaceZeroAreaCullPrimsPercent()
{
    return (BackFaceZeroAreaCullPrims() * 100) / PrimitivesSubmitted();
}

// name: Guard Band Cull Primitives
// description: Number of primitives being culled due to being outside guard band
// type: Count
function GuardBandCullPrims()
{
    return _4b1f5c87264cd5cd23bb5eb652d21194fb7f49f9b1d70433f180b31a7a22dcab_vtx + _4bb4ab3f3e64c565175f4fbe0f75df41b12c3bc2b4242b99cd4a330773d475d4_vtx + _d7b92925765e8d20627989863f1b950ec5d6dffbd815c4c100730b3a7e7801fd_vtx;
}

// name: Guard Band Cull Primitives %
// description: % of primitives being culled due to being outside guard band
// type: Percentage
function GuardBandCullPrimsPercent()
{
    return GuardBandCullPrims() * 100 / PrimitivesSubmitted();
}

// name: Off-screen Cull Primitives
// description: Number of primitives being culled due to being off-screen
// type: Count
function OffscreenCullPrims()
{
    return _0f9aab25f0863ace3de6f9832139250c806045a7ac0d6f8cf06c682c282005f1_vtx + _dbe3d527893309548e6eebdee711a622433c869e148727cf18e31ae63cf116d3_vtx + _3bd7a95222e8315bf62e84ba01a511e64bd7aa7487bed322a8ac96e4c4e628e1_vtx;
}

// name: Off-screen Cull Primitives %
// description: % of primitives being culled due to being off-screen
// type: Percentage
function OffscreenCullPrimsPercent()
{
    return OffscreenCullPrims() * 100 / PrimitivesSubmitted();
}

// name: Cull Unit Utilization %
// description: % Cull Unit Utilization
// type: Percentage
function CullerExecutePercent()
{
    return _c3bf601f0a951d8e293718574d5f9ce5ddcb27d830ef81f6b018a3b933194ce1_norm_vtx / num_gps;
}

// name: Cull Unit Stall %
// description: % Cull Unit Stall
// type: Percentage
function CullerStallPercent()
{
    return _8e9ab396d9f5da7c76d35056a740301891a7f4f5f7ff73af6776c39fb2d839eb_norm_vtx / num_gps;
}

// name: Clipper Unit Utilization %
// description: % Clipper Unit Utilization
// type: Percentage
function ClipperExecutePercent()
{
    return _ba42c3f46d52663d076f226bfb30be092b4b536d27d161d16869c10288811903_norm_vtx / num_gps;
}

// name: Fragments Rasterized
// description: Number of fragments rasterized
// type: Count
function FragmentsRasterized()
{
    return _7cef4e481233623472ea3e1f6b4131fabb20f247f7e5eae173dfd693aa60d0ff * 32;
}

// name: Pre Z Fail Count
// description: Pre Z Fail Count
// type: Count
function PreZFailCount()
{
    return (_7cef4e481233623472ea3e1f6b4131fabb20f247f7e5eae173dfd693aa60d0ff - _24be79c8d8f70844505a88372d5027b6f8afd064ccbab97ac3ffe36dd5a0ef2b) * 32;
}

// name: Pre Z Fail %
// description: % Pre Z Fail
// type: Percentage
function PreZFailCountPercent()
{
    return (_7cef4e481233623472ea3e1f6b4131fabb20f247f7e5eae173dfd693aa60d0ff - _24be79c8d8f70844505a88372d5027b6f8afd064ccbab97ac3ffe36dd5a0ef2b) * 100 / _7cef4e481233623472ea3e1f6b4131fabb20f247f7e5eae173dfd693aa60d0ff;
}

// name: Pre Z Pass Count
// description: Pre Z Pass Count
// type: Count
function PreZPassCount()
{
    return _24be79c8d8f70844505a88372d5027b6f8afd064ccbab97ac3ffe36dd5a0ef2b * 32;
}

// name: Pre Z Pass %
// description: % Pre Z Pass
// type: Percentage
function PreZPassCountPercent()
{
    return (_24be79c8d8f70844505a88372d5027b6f8afd064ccbab97ac3ffe36dd5a0ef2b * 100) / _7cef4e481233623472ea3e1f6b4131fabb20f247f7e5eae173dfd693aa60d0ff;
}

// name: VS Texture Cache Miss Rate
// description: Percentage of time L1 Texture Cache access is a Miss
// type: Percentage
function VSTextureCacheMissRate()
{
    return _19109618d2fc2db66c23fe425a0a19ec06c81f05bb676c40aa572b76891428e6_vtx * 100 / (4.0 * _a8aac8549e9e4a65ca6d3143f42067a6b99241a9a056d0bb512624ee4a91ebc6_vtx + 3.0 * _c0d09f7c090cf4aba7f28554d5fbc55c24426ef3c548a77fa8def417b1823500_vtx + 2.0 * _5a879b789f129c90cada6c1f3173468a47dbc0b43eb8f7e0f8c9602136a0ae0d_vtx + _c5abc56251535ca5b6258367a41d21e518b437e511763fe0d6f0e84ec115ff41_vtx)
}

// name: FS Texture Cache Miss Rate
// description: Percentage of time L1 Texture Cache access is a Miss
// type: Percentage
function FSTextureCacheMissRate()
{
    return _19109618d2fc2db66c23fe425a0a19ec06c81f05bb676c40aa572b76891428e6_frg  * 100 / (4.0 * _a8aac8549e9e4a65ca6d3143f42067a6b99241a9a056d0bb512624ee4a91ebc6_frg + 3.0 * _c0d09f7c090cf4aba7f28554d5fbc55c24426ef3c548a77fa8def417b1823500_frg + 2.0 * _5a879b789f129c90cada6c1f3173468a47dbc0b43eb8f7e0f8c9602136a0ae0d_frg + _c5abc56251535ca5b6258367a41d21e518b437e511763fe0d6f0e84ec115ff41_frg)
}

// name: VS Texture samples
// description: VS Texture samples
// type: Count
function VSTextureSamples()
{
    return _ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507_vtx * 64
}

// name: FS Texture samples
// description: FS Texture samples
// type: Count
function FSTextureSamples()
{
   return _ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507_frg * 64
}

// name: CS Texture samples
// description: CS Texture samples
// type: Count
function CSTextureSamples()
{
   return _ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507_cmp * 64
}

// name: Texture samples per invocation
// description: VS Texture samples per invocation
// type: Rate
function VSTextureSamplesPerInvocation()
{
    return VSTextureSamples() / VSInvocation()
}

// name: Texture samples per invocation
// description: FS Texture samples per invocation
// type: Rate
function FSTextureSamplesPerInvocation()
{
    return FSTextureSamples() / PSInvocation()
}

// name: Texture samples per invocation
// description: CS Texture samples per invocation
// type: Rate
function CSTextureSamplesPerInvocation()
{
    return CSTextureSamples() / CSInvocation()
}

// name: Average Anisotropic Ratio
// description: Average Anisotropic Ratio
// type: Rate
function AverageAnisotropicRatio()
{
    var total = _a7e72038471917bb4125254ae57103538d43fd9d4a233b06a1f248ca3bfc11ac +
                2 * _f76e110e78dbd810843354c733691fcfcd8a5624a46d34e887797178f903ab95 +
                3 * _ce8d2278e7b086459bd4cccfe0b5c79b13ff287bf60e12cb62113d7478856b46 +
                4 * _88a70ef450a839c73c44e1ebf268aa13bf92a5179d6ff3ab45ac0006fa8544cd +
                6 * _851e2825825612ac09e7b26350dc1b5b05998c3aab3198f4a2921768a84dfbbb +
                8 * _b48ed13a188e430f6a5bd26a74642ceabd518b8d290fe8322ebc00a7671bef9d +
                10 * _3b22188697e2c64b322decfb2df85c2cd7a7f264312a00737b10231811737d35 +
                12 * _14a170fde3d2efeda34d72f062b69852d6b927feb012e65ae602e9c41c3565ba +
                14 * _57bf025a3b6e220efeee5fb9ecd97ad51c6adcccb96ca62426cc096e38eb9aa0 +
                16 * _d86114b5bc1b6abf8638dd305669a55d8b394e5709b8e33e585d73c184d18943;
        
    return Math.round(total / _838e506beb7a1376c2242cd5738a6016661bdfccb78c105f3ce081c89735bc9d);
}

// name: Total Texture Samples
// description: Total Number of texture samples
// type: Count
function TextureSamples()
{
    return _ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507 * 64;
}

// name: Anisotropic Samples
// description: Number of texture samples with anisotropic filtering
// type: Count
function AnisotropicSamples()
{
    return _838e506beb7a1376c2242cd5738a6016661bdfccb78c105f3ce081c89735bc9d * 4;
}

// name: Anisotropic Samples %
// description: % of texture samples with anisotropic filtering
// type: Percentage
function AnisotropicSamplesPercent()
{
    return (_838e506beb7a1376c2242cd5738a6016661bdfccb78c105f3ce081c89735bc9d * 100) / (_0927651557827fd5468721c2ee04ff7924ebb553f9e0acc6b504a791aefdf935 * 64);
}

// name: Mipmap Linear Samples
// description: Number of texture samples with linear mipmap filter
// type: Count
function MipmapLinearSamples()
{
    return _b7afe579643b48d1495eb528fa5a78db4c0a065f75636f39f24f9cf4578912cf * 4;
}

// name: Mipmap Linear Samples %
// description: % of texture samples with linear mipmap filter
// type: Percentage
function MipmapLinearSamplesPercent()
{
    return (_b7afe579643b48d1495eb528fa5a78db4c0a065f75636f39f24f9cf4578912cf * 100) / (_0927651557827fd5468721c2ee04ff7924ebb553f9e0acc6b504a791aefdf935 * 64);
}

// name: Mipmap Nearest Samples
// description: Number of texture samples with nearest mipmap filter
// type: Count
function MipmapNearestSamples()
{
    return _443fdcc2095b4dca2f7e327fb6af5914523d670164b66d05316044de82474149 * 4;
}

// name: Mipmap Nearest Samples %
// description: % of texture samples with nearest mipmap filter
// type: Percentage
function MipmapNearestSamplesPercent()
{
    return (_443fdcc2095b4dca2f7e327fb6af5914523d670164b66d05316044de82474149 * 100) / (_0927651557827fd5468721c2ee04ff7924ebb553f9e0acc6b504a791aefdf935 * 64);
}

// name: Compressed Texture Samples
// description: Number of compressed texture samples
// type: Count
function CompressedSamples()
{
    var CompressedSamples = _c9c95eb1a34eb7174e53a1b1edaf53792e68f9976bc8eb07fce8ad493bddc08e +
                            _3de788cd53ebf174aa407ea16ef4db42a9c5b26ec73c4d2f90713dd56d65f333 +
                            _fa01d5329f611805a99f4699e796d485f8f993df07816be0c8b15ac5e39951ea +
                            _0b4c966855c4b581f07ec85a1491cb234d31a838aaf82adc9427d3b2497bd31c +
                            _3bdd2971a0eab63c90d85f332aaf54f1f94663a4057f3c5d7619e2442d091a31 +
                            _4e088158f4d8adbbe88420686b1cb8700f71b4a42277c8b25c3f00bb97008361 +
                            _0427b329a9bf6f3b297e589bdebcd2e8a222101e677f95061e2fbe6fbe4ffa6f +
                            _4abe7d6426efbcb52bcc749d398c408464e07bccc54a687a42b794009dee6158 +                            
                            _71b154ef77c3d0492cf30c6594c523c8abe3285ee44c7f73c15ab86fabc4f05e +
                            _e2eebf0eaa57027e8dfa6003d4f8f90fb00c3666b62e391d060b8730c80b020f +
                            _46ed86682cc445fce72ee444d0a285905c9acb73971662dc88cf1fbc7f637928 +
                            _ccbd9b2a02319dfae2b510714bf280d5869ae5b980a89f854023778e59e8fb8b +
                            _0170b0014687cc7dc054a9619094bc011a05d098930b07f0b7dab0bcabae9406 +
                            _282cfcc4b531f88df1917e61edd71b551c4de0f3cc74785a95cdeaf421efefe2;

    return CompressedSamples * 4;
}

// name: Compressed Samples %
// description: Percentage of samples to compressed textures
// type: Percentage
function CompressedSamplesPercent()
{
    var CompressedSamples = _c9c95eb1a34eb7174e53a1b1edaf53792e68f9976bc8eb07fce8ad493bddc08e +
                            _3de788cd53ebf174aa407ea16ef4db42a9c5b26ec73c4d2f90713dd56d65f333 +
                            _fa01d5329f611805a99f4699e796d485f8f993df07816be0c8b15ac5e39951ea +
                            _0b4c966855c4b581f07ec85a1491cb234d31a838aaf82adc9427d3b2497bd31c +
                            _3bdd2971a0eab63c90d85f332aaf54f1f94663a4057f3c5d7619e2442d091a31 +
                            _4e088158f4d8adbbe88420686b1cb8700f71b4a42277c8b25c3f00bb97008361 +
                            _0427b329a9bf6f3b297e589bdebcd2e8a222101e677f95061e2fbe6fbe4ffa6f +
                            _4abe7d6426efbcb52bcc749d398c408464e07bccc54a687a42b794009dee6158 +
                            _71b154ef77c3d0492cf30c6594c523c8abe3285ee44c7f73c15ab86fabc4f05e +
                            _e2eebf0eaa57027e8dfa6003d4f8f90fb00c3666b62e391d060b8730c80b020f +
                            _46ed86682cc445fce72ee444d0a285905c9acb73971662dc88cf1fbc7f637928 +
                            _ccbd9b2a02319dfae2b510714bf280d5869ae5b980a89f854023778e59e8fb8b +
                            _0170b0014687cc7dc054a9619094bc011a05d098930b07f0b7dab0bcabae9406 +
                            _282cfcc4b531f88df1917e61edd71b551c4de0f3cc74785a95cdeaf421efefe2;

    return (CompressedSamples * 100) / (_0927651557827fd5468721c2ee04ff7924ebb553f9e0acc6b504a791aefdf935 * 64);
}

// name: Pixels Written to Memory
// description: Number of pixels written to memory
// type: Count
function PixelsWrittenToMemory()
{
    return _f406f88bdd312ec0455d0943c388de77e53b86cf0109624b028c3aa596ec3bf4 * 4;
}

// name: Pixel Write Stall
// description: % Pixel Write Stall
// type: Percentage
function PixelWriteStallPercent()
{
    return (_63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67 * 100) / (_63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67 + _bb9dbea90df77e54beebae872b35923d727fd2a59d6905410b32092d6d561402);
}

// name: Texture Sample Limiter
// description: Measures the time during which texture samples are attempted to execute as a percentage of peak texture sample performance.
// type: Percentage
function TPULimiter()
{    
    return _7646a8523871192073a29fb3af219f4dbddae3339e969e0da8ef8d84a3d46ec5_norm / (2.0 * num_cores);
}   

// name: Vertex Texture Sample Limiter
// description: Vertex texture sample limiter
// type: Percentage
function VertexTPULimiter()
{    
    return _7646a8523871192073a29fb3af219f4dbddae3339e969e0da8ef8d84a3d46ec5_norm_vtx / (2.0 * num_cores);
}   

// name: Fragment Texture Sample Limiter
// description: Fragment texture sample limiter
// type: Percentage
function FragmentTPULimiter()
{
    return _7646a8523871192073a29fb3af219f4dbddae3339e969e0da8ef8d84a3d46ec5_norm_frg / (2.0 * num_cores);
}   

// name: ALU Limiter
// description: Measures the time during which ALU work is attempted to execute as a percentage of peak ALU performance.
// type: Percentage
function ALULimiter()
{    
    return (_c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_norm + _d201fed97c60848e3714502b203a0ad4e2820937c140dbf6a9db1cb31be194dd_norm) / (2 * num_cores);
}

// name: Vertex ALU Limiter
// description: Vertex ALU Limiter
// type: Percentage
function VertexALULimiter()
{
    return (_c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_norm_vtx + _d201fed97c60848e3714502b203a0ad4e2820937c140dbf6a9db1cb31be194dd_norm_vtx) / (2 * num_cores);
}

// name: Fragment ALU Limiter
// description: Fragment ALU Limiter
// type: Percentage
function FragmentALULimiter()
{
    return (_c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_norm_frg + _d201fed97c60848e3714502b203a0ad4e2820937c140dbf6a9db1cb31be194dd_norm_frg) / (2 * num_cores);
}

// name: Texture Write Limiter
// description: Measures the time during which texture writes are attempted to execute as a percentage of peak texture write performance.
// type: Percentage
function PBELimiter()
{
    return (_bb9dbea90df77e54beebae872b35923d727fd2a59d6905410b32092d6d561402_norm + _63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67_norm) / num_cores;
}

// name: VS Texture Write Limiter
// description: VS Texture write limiter
// type: Percentage
function VertexPBELimiter()
{
    return (_bb9dbea90df77e54beebae872b35923d727fd2a59d6905410b32092d6d561402_norm_vtx + _63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67_norm_vtx) / num_cores;
}

// name: FS Texture Write Limiter
// description: FS Texture write limiter
// type: Percentage
function FragmentPBELimiter()
{
    return (_bb9dbea90df77e54beebae872b35923d727fd2a59d6905410b32092d6d561402_norm_frg + _63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67_norm_frg) / num_cores;
}

// name: Sample Limiter
// description: % Sample Limiter
// type: Percentage
function SampleLimiter()
{
    return (_450c6190714cff4c691e85516367dccd4a988a331215ec899dc89670b4d6fbfa_norm + _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm) * 0.5 / num_cores;
}

// name: VS Sample Limiter
// description: % VS Sample Limiter
// type: Percentage
function VertexSampleLimiter()
{
    return (_450c6190714cff4c691e85516367dccd4a988a331215ec899dc89670b4d6fbfa_norm_vtx + _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm_vtx) * 0.5 / num_cores;
}

// name: FS Sample Limiter
// description: % FS Sample Limiter
// type: Percentage
function FragmentSampleLimiter()
{
    return (_450c6190714cff4c691e85516367dccd4a988a331215ec899dc89670b4d6fbfa_norm_frg + _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm_frg) * 0.5 / num_cores;
}

// name: VS Pixel Write Stall
// description: % VS Shader Core Pixel Write Stall
// type: Percentage
function VSPixelWriteStall()
{
    return (1.0 / num_cores) * (_63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67_norm_vtx);
}

// name: FS Pixel Write Stall
// description: % FS Shader Core Pixel Write Stall
// type: Percentage
function FSPixelWriteStall()
{
    return (1.0 / num_cores) * (_63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67_norm_frg);
}

// name: CS Pixel Write Stall
// description: % CS Shader Core Pixel Write Stall
// type: Percentage
function CSPixelWriteStall()
{
    return (1.0 / num_cores) * (_63b42fb9d33e39b5f913060438c759d841275b394631cb7a8145853e9a04ef67_norm);
}

// name: VS Sampler stall %
// description: % Sampler stalls
// type: Percentage
function VSSamplerStall()
{
    return _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm_vtx * 0.5 / num_cores;
}

// name: FS Sampler stall %
// description: % Sampler stalls
// type: Percentage
function FSSamplerStall()
{
    return _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm_frg * 0.5 / num_cores;
}

// name: CS Sampler stall %
// description: % Sampler stalls
// type: Percentage
function CSSamplerStall()
{
    return _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm_cmp * 0.5 / num_cores;
}

// name: Threadgroup/Imageblock Load Limiter
// description: Measures the time during which threadgroup and imageblock threadgroup loads are attempted to execute as a percentage of peak threadgroup and imageblock threadgroup performance.
// type: Percentage
function LocalLoadLimiter()
{
    return _7297c7ee63bc3f774b2e5f2e665cd87efcbf40dd3e6b66a9c08f8ebfdae4019e_norm / (4.0 * num_cores);
}

// name: VS Threadgroup/Imageblock Load Limiter
// description: VS Threadgroup/Imageblock load limiter
// type: Percentage
function VertexLocalLoadLimiter()
{
    return _7297c7ee63bc3f774b2e5f2e665cd87efcbf40dd3e6b66a9c08f8ebfdae4019e_norm_vtx / (4.0 * num_cores);
}

// name: FS Threadgroup/Imageblock Load Limiter
// description: FS Threadgroup/Imageblock load limiter
// type: Percentage
function FragmentLocalLoadLimiter()
{
    return _7297c7ee63bc3f774b2e5f2e665cd87efcbf40dd3e6b66a9c08f8ebfdae4019e_norm_frg / (4.0 * num_cores);
}

// name: Threadgroup/Imageblock Store Limiter
// description: Measures the time during which threadgroup and imageblock threadgroup stores are attempted to execute as a percentage of peak threadgroup and imageblock threadgroup performance.
// type: Percentage
function LocalStoreLimiter()
{
    return _192193e6c7ce23b86614fecbd983be5c3d4ea08d47c42ee19db85a736c0cbf7e_norm / (4.0 * num_cores);
}

// name: VS Threadgroup/Imageblock Store Limiter
// description: VS Threadgroup/Imageblock store limiter
// type: Percentage
function VertexLocalStoreLimiter()
{
    return _192193e6c7ce23b86614fecbd983be5c3d4ea08d47c42ee19db85a736c0cbf7e_norm_vtx / (4.0 * num_cores);
}

// name: FS Threadgroup/Imageblock Store Limiter
// description: FS Threadgroup/Imageblock store limiter
// type: Percentage
function FragmentLocalStoreLimiter()
{
    return _192193e6c7ce23b86614fecbd983be5c3d4ea08d47c42ee19db85a736c0cbf7e_norm_frg / (4.0 * num_cores);
}

// name: Texture Cache Read Miss Rate
// description: Percentage of time L1 Texture Cache read access is a Miss
// type: Percentage
function TextureCacheMissRate()
{
    return _19109618d2fc2db66c23fe425a0a19ec06c81f05bb676c40aa572b76891428e6  * 100 / (4.0 * _a8aac8549e9e4a65ca6d3143f42067a6b99241a9a056d0bb512624ee4a91ebc6 + 3.0 * _c0d09f7c090cf4aba7f28554d5fbc55c24426ef3c548a77fa8def417b1823500 + 2.0 * _5a879b789f129c90cada6c1f3173468a47dbc0b43eb8f7e0f8c9602136a0ae0d + _c5abc56251535ca5b6258367a41d21e518b437e511763fe0d6f0e84ec115ff41);
}

// name: Sampler Stall %
// description: % Sampler stalls
// type: Percentage
function SamplerStall()
{
    return _bdd31d464f4dbd8a42028ce4a2b5885958d98a8cfbf4f34e09d601dd6425efa9_norm * 0.5 / num_cores;
}

// name: Texture Cache Write Miss Rate in Vertex Shader
// description: Percentage of time L1 Texture Cache write access is a Miss for Vertex Shader
// type: Percentage
function VSTextureCacheWriteMissRate()
{
    return _f430991e42f778aeda210861eca9b8cef241898007339644eff469d83e5a6c9d_vtx * 100.0 / (_f430991e42f778aeda210861eca9b8cef241898007339644eff469d83e5a6c9d_vtx + _3459b3e3f2f8a441719d05aae2161786eded99c72d7215bb6797f836d46a3426_vtx); 
}

// name: Texture Cache Write Miss Rate in Fragment Shader
// description: Percentage of time L1 Texture Cache write access is a Miss for Fragment Shader
// type: Percentage
function FSTextureCacheWriteMissRate()
{
    return _f430991e42f778aeda210861eca9b8cef241898007339644eff469d83e5a6c9d_frg * 100.0 / (_f430991e42f778aeda210861eca9b8cef241898007339644eff469d83e5a6c9d_frg + _3459b3e3f2f8a441719d05aae2161786eded99c72d7215bb6797f836d46a3426_frg); 
}

// name: Texture Cache Write Miss Rate
// description: Percentage of time L1 Texture Cache write access is a Miss
// type: Percentage
function TextureCacheWriteMissRate()
{
    return _f430991e42f778aeda210861eca9b8cef241898007339644eff469d83e5a6c9d * 100.0 / (_f430991e42f778aeda210861eca9b8cef241898007339644eff469d83e5a6c9d + _3459b3e3f2f8a441719d05aae2161786eded99c72d7215bb6797f836d46a3426); 
}

// name: VS Bytes Read From Main Memory
// description: Total bytes read from main memory in Vertex Shader
// type: Value
function VSBytesReadFromMainMemory()
{
    return 64.0 * _7df466c5ce6d100c121c263bbbff0effc1e4806f9bdb997e3c9b3c3bd4753064_vtx;
}

// name: FS Bytes Read From Main Memory
// description: Total bytes read from main memory in Fragment Shader
// type: Value
function FSBytesReadFromMainMemory()
{
    return 64.0 * _7df466c5ce6d100c121c263bbbff0effc1e4806f9bdb997e3c9b3c3bd4753064_frg;
}

// name: Bytes Read From Main Memory
// description: Total bytes read from main memory
// type: Value
function BytesReadFromMainMemory()
{
    return 64.0 * _7df466c5ce6d100c121c263bbbff0effc1e4806f9bdb997e3c9b3c3bd4753064;
}

// name: Bytes Written To Main Memory in Vertex Shader
// description: Total bytes written to main memory in vertex shader
// type: Value
function VSBytesWrittenToMainMemory()
{
    return 64.0 * _6f5e5685be1bf243f2a5c5833c60c21e560cacf79f305fdb3f353466b0616fde_vtx;
}

// name: Bytes Written To Main Memory in Fragment Shader
// description: Total bytes written to main memory in fragment shader
// type: Value
function FSBytesWrittenToMainMemory()
{
    return 64.0 * _6f5e5685be1bf243f2a5c5833c60c21e560cacf79f305fdb3f353466b0616fde_frg;
}

// name: Bytes Written To Main Memory
// description: Total bytes written to main memory
// type: Value
function BytesWrittenToMainMemory()
{
    return 64.0 * _6f5e5685be1bf243f2a5c5833c60c21e560cacf79f305fdb3f353466b0616fde;
}

// name: VS L2 Bytes Read
// description: Total L2 bytes read in Vertex Shader
// type: Value
function VSTotalL2BytesRead()
{
    return 64.0 * (_ef52925e500884ba6b276e576ae78b97fd8448dfadeba596c2202b5202e246c3_vtx + _43fe12d20dfe3a9ea7b303773d624405e026e20b2c550822f2587997d2557f13_vtx);
}

// name: FS L2 Bytes Read
// description: Total L2 bytes read in fragment shader
// type: Value
function FSTotalL2BytesRead()
{
    return 64.0 * (_ef52925e500884ba6b276e576ae78b97fd8448dfadeba596c2202b5202e246c3_frg + _43fe12d20dfe3a9ea7b303773d624405e026e20b2c550822f2587997d2557f13_frg);
}

// name: L2 Bytes Read
// description: Total L2 bytes read
// type: Value
function TotalL2BytesRead()
{
    return 64.0 * (_ef52925e500884ba6b276e576ae78b97fd8448dfadeba596c2202b5202e246c3 + _43fe12d20dfe3a9ea7b303773d624405e026e20b2c550822f2587997d2557f13);
}

// name: VS L2 bytes written
// description: Total L2 Bytes Written in vertex shader
// type: Value
function VSTotalL2BytesWritten()
{
    return 64.0 * (_d7a23701e11432625d46f02ff35668e60e55a7706704976facfe5fbeea3b1936_vtx + _56a63abf333e0f9f06f1a00635d4125c3910b3c00286e4fb3652687402916c8a_vtx);
}

// name: FS L2 Bytes Written
// description: Total L2 bytes written in fragment shader
// type: Value
function FSTotalL2BytesWritten()
{
    return 64.0 * (_d7a23701e11432625d46f02ff35668e60e55a7706704976facfe5fbeea3b1936_frg + _56a63abf333e0f9f06f1a00635d4125c3910b3c00286e4fb3652687402916c8a_frg);
}

// name: L2 Bytes Written
// description: Total L2 bytes written
// type: Value
function TotalL2BytesWritten()
{
    return 64.0 * (_d7a23701e11432625d46f02ff35668e60e55a7706704976facfe5fbeea3b1936 + _56a63abf333e0f9f06f1a00635d4125c3910b3c00286e4fb3652687402916c8a);
}

// name: VS Total Texture L1 Bytes Read
// description: Total bytes read from texture L1 cache in vertex shader
// type: Value
function VSTotalBytesReadFromTextureL1Cache()
{
    return 16.0*(4.0 * _a8aac8549e9e4a65ca6d3143f42067a6b99241a9a056d0bb512624ee4a91ebc6_vtx + 3.0 * _c0d09f7c090cf4aba7f28554d5fbc55c24426ef3c548a77fa8def417b1823500_vtx + 2.0 * _5a879b789f129c90cada6c1f3173468a47dbc0b43eb8f7e0f8c9602136a0ae0d_vtx + _c5abc56251535ca5b6258367a41d21e518b437e511763fe0d6f0e84ec115ff41_vtx);
}

// name: FS Total Texture L1 Bytes Read
// description: Total bytes read from texture L1 cache in fragment shader
// type: Value
function FSTotalBytesReadFromTextureL1Cache()
{
    return 16.0*(4.0 * _a8aac8549e9e4a65ca6d3143f42067a6b99241a9a056d0bb512624ee4a91ebc6_frg + 3.0 * _c0d09f7c090cf4aba7f28554d5fbc55c24426ef3c548a77fa8def417b1823500_frg + 2.0 * _5a879b789f129c90cada6c1f3173468a47dbc0b43eb8f7e0f8c9602136a0ae0d_frg + _c5abc56251535ca5b6258367a41d21e518b437e511763fe0d6f0e84ec115ff41_frg);
}

// name: Texture L1 Bytes Read
// description: Total bytes read from texture L1 cache
// type: Value
function TotalBytesReadFromTextureL1Cache()
{
    return 16.0*(4.0 * _a8aac8549e9e4a65ca6d3143f42067a6b99241a9a056d0bb512624ee4a91ebc6 + 3.0 * _c0d09f7c090cf4aba7f28554d5fbc55c24426ef3c548a77fa8def417b1823500 + 2.0 * _5a879b789f129c90cada6c1f3173468a47dbc0b43eb8f7e0f8c9602136a0ae0d + _c5abc56251535ca5b6258367a41d21e518b437e511763fe0d6f0e84ec115ff41);
}

// name: VS Buffer L1 Bytes Read
// description: Total bytes read from buffer L1 cache in vertex shader
// type: Value
function VSTotalBytesReadFromBufferL1Cache()
{
    return _f3b0ac2ff165c0670b2240e2ab5a6536283a3731be38544cccd5d6393815b687_vtx * 16.0;
}

// name: FS Buffer L1 Bytes Read
// description: Total bytes read from buffer L1 cache in fragment shader
// type: Value
function FSTotalBytesReadFromBufferL1Cache()
{
    return _f3b0ac2ff165c0670b2240e2ab5a6536283a3731be38544cccd5d6393815b687_frg * 16.0;
}

// name: Buffer L1 Bytes Read
// description: Total bytes read from buffer L1 cache
// type: Value
function TotalBytesReadFromBufferL1Cache()
{
    return _f3b0ac2ff165c0670b2240e2ab5a6536283a3731be38544cccd5d6393815b687 * 16.0;
}

// name: VS Buffer L1 Bytes Written
// description: Total bytes written to buffer L1 cache in vertex shader
// type: Value
function VSTotalBytesWrittenBufferL1Cache()
{
    return _dcc19066dda99b0411d8c63a3e83f6f7f1d98ab35e1abb6ea67d0cc2c48fb902_vtx * 16.0;
}

// name: FS Buffer L1 Bytes Written
// description: Total bytes written to buffer L1 cache in fragment shader
// type: Value
function FSTotalBytesWrittenBufferL1Cache()
{
    return _dcc19066dda99b0411d8c63a3e83f6f7f1d98ab35e1abb6ea67d0cc2c48fb902_frg * 16.0;
}

// name: Buffer L1 Bytes Written
// description: Total bytes written to buffer L1 cache
// type: Value
function TotalBytesWrittenBufferL1Cache()
{
    return _dcc19066dda99b0411d8c63a3e83f6f7f1d98ab35e1abb6ea67d0cc2c48fb902 * 16.0;
}

// name: Predicated Texture Thread Writes
// description: Percentage thread predicated out due to divergent control flow or small primitives covering part of quad in the render target on texture writes
// type: Percentage
function PredicatedTextureWritePercentage()
{
    if (_f406f88bdd312ec0455d0943c388de77e53b86cf0109624b028c3aa596ec3bf4 + _9da983fb76d81017bb17c1307769e9cdaa3547cc33eadcf7f389043343c66b31 > 0)
    {
        return Math.max(100.0 * (1.0 - _f406f88bdd312ec0455d0943c388de77e53b86cf0109624b028c3aa596ec3bf4 / _9da983fb76d81017bb17c1307769e9cdaa3547cc33eadcf7f389043343c66b31), 0.0);
    }
    return 0.0;
}

// name: Predicated Texture Thread Reads
// description: Percentage threads predicated out due to divergent control flow or small primitives covering part of quad in the render target on texture reads
// type: Percentage
function PredicatedTextureReadPercentage()
{
    if (_ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507 + _0927651557827fd5468721c2ee04ff7924ebb553f9e0acc6b504a791aefdf935 > 0)
    {
        return Math.max(100.0 * (1.0 - _ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507 / (4.0*_0927651557827fd5468721c2ee04ff7924ebb553f9e0acc6b504a791aefdf935)), 0.0);
    }
    return 0.0;
}

// name: Samples Shaded Per Tile
// description: Samples shaded per tile
// type: Rate
function SamplesShadedPerTile()
{
    return 64.0 * _416b2a4855c3ad10e45eaab8493e7651ad66f8e3d44ad880fa8111c87ccd090a / _ca4f98aedca7c2af2fbe442c6a08a2fd8c0c8c108470beb93831ec614a5368c1;
}

// name: VS Predicated Out ALU Percentage
// description: Percentage issued ALU operations predicated out due to divergent control flow in the verex shader
// type: Percentage
function VSPredicatedALUPercentage()
{
    var instructionsIssued = 64.0 * (_56f32468b5a600a7b4ced42046227821c172db812776abd467351b63e60753fa_vtx + _81f96c9af4c138f568c1991f43b8abc96afe15867186820facc702e97fad2bb6_vtx + _74cb63796dc0fec87ce33cd81346132d1923bb28d8b77098f59e322fe33b4dcb_vtx + _48d60a545f15574a5ec6212cad7ec4799dbf4f0354c7fa7073be4f2e3e71ad7a_vtx);
    var instructionsExecuted = 16.0 * (_82b2f93079459b00fb869444cfcf44604cc1a91d28078cd6bfd7bb6ea6ba423d_vtx + _8e70441b8b0d9ded3ed900ec761f9f5960b106c5a304b44d62781621d5d1861a_vtx + _23c51175314006fa4b6798dcb173a814349e2e5947244cfdba868be736d2bc03_vtx + _827783963eafa9275a53fc2b3ef13214ab90939fcc81572c4260e2eac9bd2acb_vtx);

    if (instructionsIssued + instructionsExecuted > 0)
    {
        return Math.max(100.0 * (1.0 - instructionsExecuted / instructionsIssued), 0.0);
    }
    return 0.0;
}

// name: FS Predicated Out ALU Percentage
// description: Percentage issued ALU operations predicated out due to divergent control flow in the fragment shader
// type: Percentage
function FSPredicatedALUPercentage()
{
    var instructionsIssued = 64.0 * (_56f32468b5a600a7b4ced42046227821c172db812776abd467351b63e60753fa_frg + _81f96c9af4c138f568c1991f43b8abc96afe15867186820facc702e97fad2bb6_frg + _74cb63796dc0fec87ce33cd81346132d1923bb28d8b77098f59e322fe33b4dcb_frg + _48d60a545f15574a5ec6212cad7ec4799dbf4f0354c7fa7073be4f2e3e71ad7a_frg);
    var instructionsExecuted = 16.0 * (_82b2f93079459b00fb869444cfcf44604cc1a91d28078cd6bfd7bb6ea6ba423d_frg + _8e70441b8b0d9ded3ed900ec761f9f5960b106c5a304b44d62781621d5d1861a_frg + _23c51175314006fa4b6798dcb173a814349e2e5947244cfdba868be736d2bc03_frg + _827783963eafa9275a53fc2b3ef13214ab90939fcc81572c4260e2eac9bd2acb_frg);

    if (instructionsIssued + instructionsExecuted > 0)
    {
        return Math.max(100.0 * (1.0 - instructionsExecuted / instructionsIssued), 0.0);
    }
    return 0.0;
}

// name: Kernel Predicated Out ALU Percentage
// description: Percentage issued ALU operations predicated out due to divergent control flow in the compute shader
// type: Percentage
function CSPredicatedALUPercentage()
{
    var instructionsIssued = 64.0 * (_56f32468b5a600a7b4ced42046227821c172db812776abd467351b63e60753fa_cmp + _81f96c9af4c138f568c1991f43b8abc96afe15867186820facc702e97fad2bb6_cmp + _74cb63796dc0fec87ce33cd81346132d1923bb28d8b77098f59e322fe33b4dcb_cmp + _48d60a545f15574a5ec6212cad7ec4799dbf4f0354c7fa7073be4f2e3e71ad7a_cmp);
    var instructionsExecuted = 16.0 * (_82b2f93079459b00fb869444cfcf44604cc1a91d28078cd6bfd7bb6ea6ba423d_cmp + _8e70441b8b0d9ded3ed900ec761f9f5960b106c5a304b44d62781621d5d1861a_cmp + _23c51175314006fa4b6798dcb173a814349e2e5947244cfdba868be736d2bc03_cmp + _827783963eafa9275a53fc2b3ef13214ab90939fcc81572c4260e2eac9bd2acb_cmp);

    if (instructionsIssued + instructionsExecuted > 0)
    {
        return Math.max(100.0 * (1.0 - instructionsExecuted / instructionsIssued), 0.0);
    }
    return 0.0;
}

// name: Thread Group Bytes Read
// description: Total bytes read from thread group memory
// type: Value
function TotalBytesReadFromThreadGroupMemory()
{
    return 16.0 * _4f6aebbe216cd96fa4684995ac68478cbdb59c6706480ecbbb9f101d892bb540;
}

// name: FS Image Block And Thread Group Memory Bytes Read
// description: Total bytes read from image block and thread group memory in fragment shader
// type: Value
function FSTotalBytesReadFromImageBlockMemory()
{
    return 16.0 * _4f6aebbe216cd96fa4684995ac68478cbdb59c6706480ecbbb9f101d892bb540_frg;
}

// name: Thread Group Bytes Written
// description: Total bytes written to thread group memory
// type: Value
function TotalBytesWrittenThreadGroupMemory()
{
    return 16.0 * _968353d331d798ff8c65ce5f1d5294c1f4bcd54f8004fe37c0ec8e0327bdb887;
}

// name: FS Image Block Memory Bytes Written
// description: Total bytes written to image block and thread group memory in fragment shader
// type: Value
function FSTotalBytesWrittenImageBlockMemory()
{
    return 16.0 * _968353d331d798ff8c65ce5f1d5294c1f4bcd54f8004fe37c0ec8e0327bdb887_frg;
}

// name: Compression Ratio of Texture Memory Written
// description: Ratio of compressed to uncomressed texture memory written
// type: Rate
function CompressionRatioTextureMemoryWritten()
{
    var cmpUncompressedDataBytes =
        16 * _b0c17a5c575cab4f46333e38bd6c5902886cb23f0b0bdd39ee50a545af04f980 +
        16 * _29d1821c8f9a15b9486ef2d149a664089d8baf032b29051eb8c4dbffad95563a +
         8 * _ab00529c9f233f26d1887a6552565a5c815d7206fae8e841e96653d6e44d9720 +
        32 * _73a07a4eb409d7dcb5949ffd6f41cd2f15b0af9dff6303cff06971131fd13dff +
        16 * _820d6093023c1b36179134d53e2590bc112fb8589e446faccb6c1ff32b803a44 +
         8 * _3f4145264446ac3fa9165321f5ce12ea5284d0b621920a5fd65e32beac4d6f8e +
         8 * _36cab0e3ce544617b00b2244cfa7202ae54954238de0d91881ca83f4e6006890 +
        16 * _ed166f4251f67b6fe851d995eef5a54810e539a33c13bebd46871f67c1257db9 +
        16 * _671c439841f54003d8b1841ee0686bae625654ce991af1ece3a9b85634720775 +
        32 * _7bfee75e8041af01e3f7bd62a11b4cbda9b5ecb054574ace923b113697916b22 +
        32 * _9bb1a0053cbf09e81970aafc5720e4e418c43e0b2c326f087ded04c65dbc0e9b +
        16 * _f8d45e0cb94a971819230fc94c9950574e128a668e4eb6af960d96a404e90992 +
         8 * _1c29b926ad18fee198bc9230dfdfdae383ec4d829a4be6b302ec5674f781ae10 +
         8 * _31f574c0d389246aecbc0a13edc218efe1f3530ad60535b352359f1b972a4ba4 +
         8 * _a73165b1618dd20a1cb5f732d8b79c01aa4e6de5d3a38bfb671bac7f386d7af7 +
        16 * _0b35f4e73bc24b0ddbf89f7eacab636514e7feb92400e7043d49c3a3f16085a6 +
        16 * _d1e5b9d556bef5fca687ee5e774d58e824d8aafbdf63f1d2ef7a5c0821a1baa2 +
         8 * _14df6325787f09d7a0686db47d6ac8d39ec78702b4ad93734091074e6e0b91ab +
         4 * _6ccf72e51e7667238e3c39f661809a1fae562f5649a8cbf8664352226c10d500;

    var cmpCompressedDataBytes =
         32 * _65651dd1b153cec80500d6665894d232894f2c83df5507865e1ef0c3f01bc6d0 +
         64 * _908f85285b4abff4a9dadb179123e90ac796cbfd79ff8c48df85253894e112bc +
        128 * _95f000cd0a64e23286a0e749df3b5efaefc8e76bc15a12bf049ed47b71e67ae7; 

    return cmpUncompressedDataBytes / Math.max(cmpCompressedDataBytes, 1);
}

// name: Compression Ratio of Texture Memory Read
// description: Ratio of compressed to uncomressed texture memory read
// type: Rate
function CompressionRatioTextureMemoryRead()
{
    return (_1827ca25b7318e2df60eb0fe4f0c290b43054021ec3233e1fcdcf7b622fe4589 + _d71cecc319ceee3a8b2139d8eb4f992d7c1d97634b28c764596c845c528e79ff) / Math.max(_8788387fa2f782d31f4553bc55eb34284415d12b986df376e394838d5075f058, 1);
}

// name: VS Arithmetic Intensity
// description: ALU ops per byte of main memory traffic in vertex shader
// type: Rate
function VSArithmeticIntensity()
{
    return VSALUInstructions() / Math.max(1, VSBytesReadFromMainMemory() + VSBytesWrittenToMainMemory());
}

// name: FS Arithmetic Intensity
// description: ALU Time in nSec per byte of main memory transfer in fragment shader
// type: Rate
function FSArithmeticIntensity()
{
    return FSALUInstructions() / Math.max(1, FSBytesReadFromMainMemory() + FSBytesWrittenToMainMemory());
}

// name: CS Arithmetic Intensity
// description: ALU ops per byte of main memory traffic in compute shader
// type: Rate
function CSArithmeticIntensity()
{
    return CSALUInstructions() / Math.max(1, BytesReadFromMainMemory() + BytesWrittenToMainMemory());
}

// name: VS Main Memory Throughput
// description: Main memory throughput in GB/s in a vertex shader
// type: Rate
function VSMainMemoryThroughput()
{
    return (VSBytesReadFromMainMemory() + VSBytesWrittenToMainMemory()) / Math.max(1, MTLStat_nSec_vtx);
}

// name: FS Main Memory Throughput
// description: Main memory throughput in GB/s in a fragment shader
// type: Rate
function FSMainMemoryThroughput()
{
    return (FSBytesReadFromMainMemory() + FSBytesWrittenToMainMemory()) / Math.max(1, MTLStat_nSec_frg);
}

// name: Main Memory Throughput
// description: Main memory throughput in GB/s
// type: Rate
function MainMemoryThroughput()
{
    return (BytesReadFromMainMemory() + BytesWrittenToMainMemory()) / Math.max(1, MTLStat_nSec);
}

// name: VS ALU Performance
// description: ALU performance in Giga Ops / Sec in vertex shader
// type: Rate
function VSALUPerformance()
{
    return VSALUInstructions() / Math.max(1, MTLStat_nSec_vtx);
}

// name: FS ALU Performance
// description: ALU performance in Giga Ops / Sec in fragment shader
// type: Rate
function FSALUPerformance()
{
    return FSALUInstructions() / Math.max(1, MTLStat_nSec_frg);
}

// name: CS ALU Performance
// description: ALU performance in Giga Ops / Sec in compute shader
// type: Rate
function CSALUPerformance()
{
    return CSALUInstructions() / Math.max(1, MTLStat_nSec_cmp);
}

// name: Buffer Read Limiter
// description: Measures the time during which buffer loads are attempted to execute as a percentage of peak buffer load performance.
// type: Percentage
function BufferLoadLimiter()
{    
    return _224fc5057da0739817ec8947d2fb1ad3ff63c2ceb3fabe0e34719c0eb465d7e9_norm / (4.0 * num_cores);
}  

// name: VS Buffer Read Limiter
// description: VS Buffer read limiter
// type: Percentage
function VertexBufferLoadLimiter()
{    
    return _224fc5057da0739817ec8947d2fb1ad3ff63c2ceb3fabe0e34719c0eb465d7e9_norm_vtx / (4.0 * num_cores);
}

// name: FS Buffer Read Limiter
// description: FS Buffer read limiter
// type: Percentage
function FragmentBufferLoadLimiter()
{    
    return _224fc5057da0739817ec8947d2fb1ad3ff63c2ceb3fabe0e34719c0eb465d7e9_norm_frg / (4.0 * num_cores);
}

// name: Buffer Write Limiter
// description: Measures the time during which buffer stores are attempted to execute as a percentage of peak buffer load performance.
// type: Percentage
function BufferStoreLimiter()
{    
    return _b39850e6fdaf024c59701c0ee69b15fce7e4f6c92aa385e9920569a6f595745f_norm / (2.0 * num_cores);
}

// name: VS Buffer Write Limiter
// description: VS Buffer write limiter
// type: Percentage
function VertexBufferStoreLimiter()
{    
    return _b39850e6fdaf024c59701c0ee69b15fce7e4f6c92aa385e9920569a6f595745f_norm_vtx / (2.0 * num_cores);
}

// name: FS Buffer Write Limiter
// description: FS Buffer write limiter
// type: Percentage
function FragmentBufferStoreLimiter()
{    
    return _b39850e6fdaf024c59701c0ee69b15fce7e4f6c92aa385e9920569a6f595745f_norm_frg / (2.0 * num_cores);
}

// name: Fragment Input Interpolation Limiter
// description: Measures the time during which fragment shader input interpolation work is attempted to execute as a percentage of peak input interpolation performance.
// type: Percentage
function FragmentInputInterpolationLimiter()
{    
    return _e5f2d8a6cf9651b49b3b00bebdf815a5269b8c89fc3bc02057a3a14e28733495_norm / (4.0 * num_cores);
}

// name: GPU Last Level Cache Limiter
// description: Measures the time during which GPU’s last level cache is attempting to service read and write requests as a percentage of cache’s peak performance.
// type: Percentage
function L2CacheLimiter()
{
    return (_5c5c55d05fb355aa5be61ac63c88eb4a2a521a47dd8f79c18b5c1df163d5cb55_norm + _c9bcd5df6397dc8477a12ddf9358bccbbb3d8e52fc3dadab320be9bbb14fe157_norm) / 4.0;
}

// name: Vertex Occupancy
// description: Measures how many vertex shader simdgroups are concurrently running in the GPU relative to the GPU’s maximum number of concurrently running simdgroups.
// type: Percentage
function VertexOccupancy()
{
    return _4bb4a72bfa974f38e0143eef87e93ae69847e8612684f014350fb4a8c0692050_norm / (_d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a * num_cores);
}

// name: Fragment Occupancy
// description: Measures how many fragment shader simdgroups are concurrently running in the GPU relative to the GPU’s maximum number of concurrently running simdgroups.
// type: Percentage
function FragmentOccupancy()
{
    return _367a60a3f4d39b45114c57a560ad1bad4f9f62798346ead3a98f790ad32537a6_norm / (_d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a * num_cores);
}

// name: Compute Occupancy
// description: Measures how many compute shader simdgroups are concurrently running in the GPU relative to the GPU’s maximum number of concurrently running simdgroups.
// type: Percentage
function ComputeOccupancy()
{
    return _6b3a9b25a65b692ad1039bcc4c052d5a85e40a9410946c0cdf5dc85d993e2131_norm / (_d56cff6c89d6a3f5f8561cd89f1b36b2760c125d908074d984bc36678982991a * num_cores);
}

// name: GPU Read Bandwidth
// description: Measures how much memory, in gigabytes per second, are read by the GPU from a memory external to the GPU (potentially main memory).
// type: Rate
function GPUReadBandwidth()
{    
    return 64 * _7df466c5ce6d100c121c263bbbff0effc1e4806f9bdb997e3c9b3c3bd4753064 / Math.max(1, MTLStat_nSec);
}   

// name: GPU Write Bandwidth
// description: Measures how much memory, in gigabytes per second, are written by the GPU to a memory external to the GPU (potentially main memory).
// type: Rate
function GPUWriteBandwidth()
{    
    return 64 * (_6d6a7c8efb15986fa71f8bf4a6a06f8942199b36680e516766e92490607c958d - _7df466c5ce6d100c121c263bbbff0effc1e4806f9bdb997e3c9b3c3bd4753064) / Math.max(1, MTLStat_nSec);
}   

// name: ALU Utilization
// description: ALU utilization
// type: Percentage
function ALUUtilization()
{
    return _c4c7e4c8f7b6488a9a980bba9f849c9e5d8e4bbb1e2c134cef7620b6faf7d6a2_norm / (2 * num_cores);
}

// name: F32 Utilization
// description: F32 utilization
// type: Percentage
function F32Utilization()
{
    return ((_55d0c180ad87ec962138c5c289baadd6969fdd2cd21ef68ab1f91190b6c33812 / 2) * _a6e6cc683eebf697b2a31bd7d4f877afee2419f6882f55b2f4ea296c9a368b99_norm * 4) / (64 * num_cores);
}   

// name: F16 Utilization
// description: F16 utilization
// type: Percentage
function F16Utilization()
{
    return ((_55d0c180ad87ec962138c5c289baadd6969fdd2cd21ef68ab1f91190b6c33812 / 2) * _0af59bb3dd0a90f2664cd5e5601b3c56bf91e40478def55647411007dc5394d3_norm * 4) / (128 * num_cores);
}  

// name: Texture Samples Utilization
// description: Texture samples utilization
// type: Percentage
function TextureSamplesUtilization()
{
    return (64.0 * _ae304fc8bce5708ffef30935687e442d6bea78f814055a5fe6e3380013d7e507_norm) / (8.0 * num_cores);
}

// name: Texture Writes Utilization
// description: Texture writes utilization
// type: Percentage
function TextureWritesUtilization()
{
    return (4.0 * _f406f88bdd312ec0455d0943c388de77e53b86cf0109624b028c3aa596ec3bf4_norm) / (4.0 * num_cores);
}

// name: Buffer Load Utilization
// description: Buffer load utilization
// type: Percentage
function BufferLoadUtilization()
{
    return _8cd74591f03ed3eb90e0c547b8bf21ae7eed4129053f40570cce56a39a690015_norm / (4 * num_cores);
}

// name: Buffer Store Utilization
// description: Buffer store utilization
// type: Percentage
function BufferStoreUtilization()
{
    return _3dfa6da703ded5b65a76ddf0aa3f7f28f19b4a624ef77347a925f55bf66a82f5_norm / (2 * num_cores);
}

// name: Threadgroup/Imageblock Load Utilization
// description: Threadgroup/Imageblock load utilization
// type: Percentage
function LocalLoadUtilization()
{
    return _4f6aebbe216cd96fa4684995ac68478cbdb59c6706480ecbbb9f101d892bb540_norm / (4.0 * num_cores);
}   

// name: Threadgroup/Imageblock Store Utilization
// description: Threadgroup/Imageblock store utilization
// type: Percentage
function LocalStoreUtilization()
{
    return _968353d331d798ff8c65ce5f1d5294c1f4bcd54f8004fe37c0ec8e0327bdb887_norm / (4.0 * num_cores);
} 

// name: Fragment Input Interpolation Utilization
// description: Fragment input interpolation utilization
// type: Percentage
function FragmentInputInterpolationUtilization()
{
    return _95b5e692e6eefd3c235ce8ef2be2b781023c467a45108be8e5bb4beea25dfe6f_norm / (4.0 * num_cores);
}

// name: GPU Last Level Cache Utilization
// description: GPU last level cache utilization
// type: Percentage
function L2CacheUtilization()
{    
    return _5c5c55d05fb355aa5be61ac63c88eb4a2a521a47dd8f79c18b5c1df163d5cb55_norm / 4.0;
}

// name: Partial Renders count
// description: Count number of partial renders in the encoder
// type: Count
function PartialRenders()
{
    return _5018ff101ee67fee86c0348828e1c15e0a4dfdc0e37c99134711930a1c5eaa79;
}

// name: Parameter Buffer Bytes Used
// description: Parameter Buffer Bytes Used
// type: Count
function ParameterBufferBytesUsed()
{
    return _4d198d9a415b725cd301ce6cf3ecaa00d37481ec5d44c0d72094acf20d374c74;
}

// name: Frag Ticks Count
// description: Frag Tick for limiters
// type: Value
function FRGTicks()
{    
    return _06f73dd77cc4f21054a372b34a28a1d5d054ff7241ee73be67f927d897211048;
}
