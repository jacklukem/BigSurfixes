#!/bin/sh
#!/bin/bash
# simple Bash Menu Script by jackluke


printf '\e[96m;%s\a' "$color"

printf "$'\e[40m'BigSur beta USB Installer fix by jackluke"

printf "\n\n\n"

echo "Welcome to the BigSur beta USB Installer  fix for domain error as target Volume"
echo "\nApplying the ASentientBot HaxLib patch"
launchctl setenv DYLD_INSERT_LIBRARIES /Volumes/Image\ Volume/HaxLib.dylib
echo "Done"
echo "\nDisabling SIP to allow any kext patches"
csrutil disable
csrutil authenticated-root disable
echo "Done"
echo "\nSetting nvram parameter to enforce compatibility check"
nvram boot-args="-no_compat_check"
echo "Done"
echo "\nYou can close with CMD+Q and launch from Utilities the Install macOS"